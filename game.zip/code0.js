gdjs.Game_32SceneCode = {};
gdjs.Game_32SceneCode.localVariables = [];
gdjs.Game_32SceneCode.idToCallbackMap = new Map();
gdjs.Game_32SceneCode.GDPlayerObjects1= [];
gdjs.Game_32SceneCode.GDPlayerObjects2= [];
gdjs.Game_32SceneCode.GDBackgroundObjects1= [];
gdjs.Game_32SceneCode.GDBackgroundObjects2= [];
gdjs.Game_32SceneCode.GDGoldObjects1= [];
gdjs.Game_32SceneCode.GDGoldObjects2= [];
gdjs.Game_32SceneCode.GDJumpButtonObjects1= [];
gdjs.Game_32SceneCode.GDJumpButtonObjects2= [];
gdjs.Game_32SceneCode.GDMoveJoystickObjects1= [];
gdjs.Game_32SceneCode.GDMoveJoystickObjects2= [];
gdjs.Game_32SceneCode.GDPlatform_9595GroundObjects1= [];
gdjs.Game_32SceneCode.GDPlatform_9595GroundObjects2= [];
gdjs.Game_32SceneCode.GDDoubleJumpPowerupObjects1= [];
gdjs.Game_32SceneCode.GDDoubleJumpPowerupObjects2= [];
gdjs.Game_32SceneCode.GDKeyObjects1= [];
gdjs.Game_32SceneCode.GDKeyObjects2= [];
gdjs.Game_32SceneCode.GDDoorObjects1= [];
gdjs.Game_32SceneCode.GDDoorObjects2= [];
gdjs.Game_32SceneCode.GDSea_9595UrchinObjects1= [];
gdjs.Game_32SceneCode.GDSea_9595UrchinObjects2= [];
gdjs.Game_32SceneCode.GDFinishObjects1= [];
gdjs.Game_32SceneCode.GDFinishObjects2= [];
gdjs.Game_32SceneCode.GDLoseTextObjects1= [];
gdjs.Game_32SceneCode.GDLoseTextObjects2= [];
gdjs.Game_32SceneCode.GDBackground2Objects1= [];
gdjs.Game_32SceneCode.GDBackground2Objects2= [];
gdjs.Game_32SceneCode.GDWinTextObjects1= [];
gdjs.Game_32SceneCode.GDWinTextObjects2= [];
gdjs.Game_32SceneCode.GDWinObjects1= [];
gdjs.Game_32SceneCode.GDWinObjects2= [];
gdjs.Game_32SceneCode.GDLavaObjects1= [];
gdjs.Game_32SceneCode.GDLavaObjects2= [];
gdjs.Game_32SceneCode.GDStartTextObjects1= [];
gdjs.Game_32SceneCode.GDStartTextObjects2= [];
gdjs.Game_32SceneCode.GDStartButtonObjects1= [];
gdjs.Game_32SceneCode.GDStartButtonObjects2= [];
gdjs.Game_32SceneCode.GDCoinCountObjects1= [];
gdjs.Game_32SceneCode.GDCoinCountObjects2= [];
gdjs.Game_32SceneCode.GDArrowsObjects1= [];
gdjs.Game_32SceneCode.GDArrowsObjects2= [];
gdjs.Game_32SceneCode.GDTimerObjects1= [];
gdjs.Game_32SceneCode.GDTimerObjects2= [];
gdjs.Game_32SceneCode.GDADoorObjects1= [];
gdjs.Game_32SceneCode.GDADoorObjects2= [];
gdjs.Game_32SceneCode.GDYourTimeObjects1= [];
gdjs.Game_32SceneCode.GDYourTimeObjects2= [];
gdjs.Game_32SceneCode.GDLore1Objects1= [];
gdjs.Game_32SceneCode.GDLore1Objects2= [];
gdjs.Game_32SceneCode.GDLore2Objects1= [];
gdjs.Game_32SceneCode.GDLore2Objects2= [];
gdjs.Game_32SceneCode.GDLore3Objects1= [];
gdjs.Game_32SceneCode.GDLore3Objects2= [];
gdjs.Game_32SceneCode.GDFinalTextObjects1= [];
gdjs.Game_32SceneCode.GDFinalTextObjects2= [];


gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.Game_32SceneCode.GDPlayerObjects1});
gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDGoldObjects1Objects = Hashtable.newFrom({"Gold": gdjs.Game_32SceneCode.GDGoldObjects1});
gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.Game_32SceneCode.GDPlayerObjects1});
gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDSea_95959595UrchinObjects1Objects = Hashtable.newFrom({"Sea_Urchin": gdjs.Game_32SceneCode.GDSea_9595UrchinObjects1});
gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.Game_32SceneCode.GDPlayerObjects1});
gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDADoorObjects1Objects = Hashtable.newFrom({"ADoor": gdjs.Game_32SceneCode.GDADoorObjects1});
gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.Game_32SceneCode.GDPlayerObjects1});
gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDLavaObjects1Objects = Hashtable.newFrom({"Lava": gdjs.Game_32SceneCode.GDLavaObjects1});
gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.Game_32SceneCode.GDPlayerObjects1});
gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDStartButtonObjects1Objects = Hashtable.newFrom({"StartButton": gdjs.Game_32SceneCode.GDStartButtonObjects1});
gdjs.Game_32SceneCode.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Gold"), gdjs.Game_32SceneCode.GDGoldObjects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Game_32SceneCode.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDPlayerObjects1Objects, gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDGoldObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Game_32SceneCode.GDGoldObjects1 */
{for(var i = 0, len = gdjs.Game_32SceneCode.GDGoldObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDGoldObjects1[i].deleteFromScene(runtimeScene);
}
}
{gdjs.evtTools.sound.playSound(runtimeScene, "PickupCoin", false, 80, gdjs.randomFloatInRange(1, 1.1));
}
{runtimeScene.getScene().getVariables().getFromIndex(0).add(1);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Game_32SceneCode.GDPlayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("Sea_Urchin"), gdjs.Game_32SceneCode.GDSea_9595UrchinObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDPlayerObjects1Objects, gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDSea_95959595UrchinObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(14299948);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Arrows"), gdjs.Game_32SceneCode.GDArrowsObjects1);
gdjs.copyArray(runtimeScene.getObjects("Background"), gdjs.Game_32SceneCode.GDBackgroundObjects1);
gdjs.copyArray(runtimeScene.getObjects("Gold"), gdjs.Game_32SceneCode.GDGoldObjects1);
gdjs.copyArray(runtimeScene.getObjects("Lava"), gdjs.Game_32SceneCode.GDLavaObjects1);
gdjs.copyArray(runtimeScene.getObjects("LoseText"), gdjs.Game_32SceneCode.GDLoseTextObjects1);
/* Reuse gdjs.Game_32SceneCode.GDPlayerObjects1 */
/* Reuse gdjs.Game_32SceneCode.GDSea_9595UrchinObjects1 */
{for(var i = 0, len = gdjs.Game_32SceneCode.GDLoseTextObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDLoseTextObjects1[i].hide(false);
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDPlayerObjects1[i].hide();
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDBackgroundObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDBackgroundObjects1[i].hide();
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDLavaObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDLavaObjects1[i].hide();
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDGoldObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDGoldObjects1[i].hide();
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDSea_9595UrchinObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDSea_9595UrchinObjects1[i].hide();
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDArrowsObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDArrowsObjects1[i].hide();
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Arrows"), gdjs.Game_32SceneCode.GDArrowsObjects1);
gdjs.copyArray(runtimeScene.getObjects("CoinCount"), gdjs.Game_32SceneCode.GDCoinCountObjects1);
gdjs.copyArray(runtimeScene.getObjects("LoseText"), gdjs.Game_32SceneCode.GDLoseTextObjects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Game_32SceneCode.GDPlayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("StartButton"), gdjs.Game_32SceneCode.GDStartButtonObjects1);
gdjs.copyArray(runtimeScene.getObjects("Timer"), gdjs.Game_32SceneCode.GDTimerObjects1);
gdjs.copyArray(runtimeScene.getObjects("Win"), gdjs.Game_32SceneCode.GDWinObjects1);
gdjs.copyArray(runtimeScene.getObjects("YourTime"), gdjs.Game_32SceneCode.GDYourTimeObjects1);
{for(var i = 0, len = gdjs.Game_32SceneCode.GDLoseTextObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDLoseTextObjects1[i].hide();
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDPlayerObjects1[i].setCenterPositionInScene(4215,-(5900));
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDWinObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDWinObjects1[i].hide();
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDStartButtonObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDStartButtonObjects1[i].returnVariable(gdjs.Game_32SceneCode.GDStartButtonObjects1[i].getVariables().getFromIndex(0)).setNumber(0);
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDCoinCountObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDCoinCountObjects1[i].hide();
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDArrowsObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDArrowsObjects1[i].setLayer("");
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDLoseTextObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDLoseTextObjects1[i].setLayer("MobileControls");
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDWinObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDWinObjects1[i].setLayer("MobileControls");
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDTimerObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDTimerObjects1[i].hide();
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDTimerObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDTimerObjects1[i].setLayer("MobileControls");
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDYourTimeObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDYourTimeObjects1[i].hide();
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "r");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Game_32SceneCode.GDPlayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("Timer"), gdjs.Game_32SceneCode.GDTimerObjects1);
{for(var i = 0, len = gdjs.Game_32SceneCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDPlayerObjects1[i].setCenterPositionInScene(100,50);
}
}
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Game Scene", false);
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDTimerObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDTimerObjects1[i].resetTimer(gdjs.Game_32SceneCode.GDTimerObjects1[i].getVariables().getFromIndex(0).getAsString());
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("ADoor"), gdjs.Game_32SceneCode.GDADoorObjects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Game_32SceneCode.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDPlayerObjects1Objects, gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDADoorObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(0).getAsNumber() >= 35);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Game_32SceneCode.GDADoorObjects1 */
gdjs.copyArray(runtimeScene.getObjects("Background"), gdjs.Game_32SceneCode.GDBackgroundObjects1);
gdjs.copyArray(runtimeScene.getObjects("Finish"), gdjs.Game_32SceneCode.GDFinishObjects1);
gdjs.copyArray(runtimeScene.getObjects("Gold"), gdjs.Game_32SceneCode.GDGoldObjects1);
gdjs.copyArray(runtimeScene.getObjects("JumpButton"), gdjs.Game_32SceneCode.GDJumpButtonObjects1);
gdjs.copyArray(runtimeScene.getObjects("Lava"), gdjs.Game_32SceneCode.GDLavaObjects1);
gdjs.copyArray(runtimeScene.getObjects("MoveJoystick"), gdjs.Game_32SceneCode.GDMoveJoystickObjects1);
gdjs.copyArray(runtimeScene.getObjects("Platform_Ground"), gdjs.Game_32SceneCode.GDPlatform_9595GroundObjects1);
/* Reuse gdjs.Game_32SceneCode.GDPlayerObjects1 */
gdjs.copyArray(runtimeScene.getObjects("Sea_Urchin"), gdjs.Game_32SceneCode.GDSea_9595UrchinObjects1);
gdjs.copyArray(runtimeScene.getObjects("StartButton"), gdjs.Game_32SceneCode.GDStartButtonObjects1);
gdjs.copyArray(runtimeScene.getObjects("Timer"), gdjs.Game_32SceneCode.GDTimerObjects1);
gdjs.copyArray(runtimeScene.getObjects("Win"), gdjs.Game_32SceneCode.GDWinObjects1);
gdjs.copyArray(runtimeScene.getObjects("YourTime"), gdjs.Game_32SceneCode.GDYourTimeObjects1);
{for(var i = 0, len = gdjs.Game_32SceneCode.GDWinObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDWinObjects1[i].hide(false);
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDPlayerObjects1[i].hide();
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDBackgroundObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDBackgroundObjects1[i].hide();
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDFinishObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDFinishObjects1[i].hide();
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDPlatform_9595GroundObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDPlatform_9595GroundObjects1[i].hide();
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDSea_9595UrchinObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDSea_9595UrchinObjects1[i].hide();
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDGoldObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDGoldObjects1[i].hide();
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDJumpButtonObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDJumpButtonObjects1[i].hide();
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDMoveJoystickObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDMoveJoystickObjects1[i].hide();
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDLavaObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDLavaObjects1[i].hide();
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDADoorObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDADoorObjects1[i].hide();
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDStartButtonObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDStartButtonObjects1[i].returnVariable(gdjs.Game_32SceneCode.GDStartButtonObjects1[i].getVariables().getFromIndex(0)).setNumber(-(1));
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDYourTimeObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDYourTimeObjects1[i].hide(false);
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDYourTimeObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDYourTimeObjects1[i].getBehavior("Text").setText("Your Time: " + gdjs.evtTools.common.toString(Math.floor(((gdjs.Game_32SceneCode.GDTimerObjects1.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Game_32SceneCode.GDTimerObjects1[0].getVariables()).getFromIndex(0).getAsNumber())));
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDTimerObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDTimerObjects1[i].hide();
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("StartButton"), gdjs.Game_32SceneCode.GDStartButtonObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Game_32SceneCode.GDStartButtonObjects1.length;i<l;++i) {
    if ( gdjs.Game_32SceneCode.GDStartButtonObjects1[i].getVariableNumber(gdjs.Game_32SceneCode.GDStartButtonObjects1[i].getVariables().getFromIndex(0)) == 1 ) {
        isConditionTrue_0 = true;
        gdjs.Game_32SceneCode.GDStartButtonObjects1[k] = gdjs.Game_32SceneCode.GDStartButtonObjects1[i];
        ++k;
    }
}
gdjs.Game_32SceneCode.GDStartButtonObjects1.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("CoinCount"), gdjs.Game_32SceneCode.GDCoinCountObjects1);
gdjs.copyArray(runtimeScene.getObjects("Lava"), gdjs.Game_32SceneCode.GDLavaObjects1);
gdjs.copyArray(runtimeScene.getObjects("Timer"), gdjs.Game_32SceneCode.GDTimerObjects1);
{for(var i = 0, len = gdjs.Game_32SceneCode.GDLavaObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDLavaObjects1[i].setX((gdjs.Game_32SceneCode.GDLavaObjects1[i].getPointX("")) + 1.8);
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDCoinCountObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDCoinCountObjects1[i].hide(false);
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDCoinCountObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDCoinCountObjects1[i].getBehavior("Text").setText("Coins: " + runtimeScene.getScene().getVariables().getFromIndex(0).getAsString() + "/35");
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDTimerObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDTimerObjects1[i].getBehavior("Text").setText("Time: " + gdjs.evtTools.common.toString(Math.floor(gdjs.Game_32SceneCode.GDTimerObjects1[i].getVariables().getFromIndex(0).getAsNumber())));
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDTimerObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDTimerObjects1[i].returnVariable(gdjs.Game_32SceneCode.GDTimerObjects1[i].getVariables().getFromIndex(0)).add(0.016666667);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Lava"), gdjs.Game_32SceneCode.GDLavaObjects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Game_32SceneCode.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDPlayerObjects1Objects, gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDLavaObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(14310156);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Arrows"), gdjs.Game_32SceneCode.GDArrowsObjects1);
gdjs.copyArray(runtimeScene.getObjects("Background"), gdjs.Game_32SceneCode.GDBackgroundObjects1);
gdjs.copyArray(runtimeScene.getObjects("Gold"), gdjs.Game_32SceneCode.GDGoldObjects1);
/* Reuse gdjs.Game_32SceneCode.GDLavaObjects1 */
gdjs.copyArray(runtimeScene.getObjects("LoseText"), gdjs.Game_32SceneCode.GDLoseTextObjects1);
/* Reuse gdjs.Game_32SceneCode.GDPlayerObjects1 */
{for(var i = 0, len = gdjs.Game_32SceneCode.GDLoseTextObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDLoseTextObjects1[i].hide(false);
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDPlayerObjects1[i].hide();
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDBackgroundObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDBackgroundObjects1[i].hide();
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDLavaObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDLavaObjects1[i].hide();
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDGoldObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDGoldObjects1[i].hide();
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDArrowsObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDArrowsObjects1[i].hide();
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Game_32SceneCode.GDPlayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("StartButton"), gdjs.Game_32SceneCode.GDStartButtonObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDPlayerObjects1Objects, gdjs.Game_32SceneCode.mapOfGDgdjs_9546Game_959532SceneCode_9546GDStartButtonObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Game_32SceneCode.GDPlayerObjects1 */
/* Reuse gdjs.Game_32SceneCode.GDStartButtonObjects1 */
gdjs.copyArray(runtimeScene.getObjects("Timer"), gdjs.Game_32SceneCode.GDTimerObjects1);
{for(var i = 0, len = gdjs.Game_32SceneCode.GDStartButtonObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDStartButtonObjects1[i].returnVariable(gdjs.Game_32SceneCode.GDStartButtonObjects1[i].getVariables().getFromIndex(0)).setNumber(1);
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDPlayerObjects1[i].setPosition(128,256);
}
}
{for(var i = 0, len = gdjs.Game_32SceneCode.GDTimerObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDTimerObjects1[i].hide(false);
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Up");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Game_32SceneCode.GDPlayerObjects1);
{for(var i = 0, len = gdjs.Game_32SceneCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.Game_32SceneCode.GDPlayerObjects1[i].getBehavior("PlatformerObject").simulateJumpKey();
}
}
}

}


};

gdjs.Game_32SceneCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Game_32SceneCode.GDPlayerObjects1.length = 0;
gdjs.Game_32SceneCode.GDPlayerObjects2.length = 0;
gdjs.Game_32SceneCode.GDBackgroundObjects1.length = 0;
gdjs.Game_32SceneCode.GDBackgroundObjects2.length = 0;
gdjs.Game_32SceneCode.GDGoldObjects1.length = 0;
gdjs.Game_32SceneCode.GDGoldObjects2.length = 0;
gdjs.Game_32SceneCode.GDJumpButtonObjects1.length = 0;
gdjs.Game_32SceneCode.GDJumpButtonObjects2.length = 0;
gdjs.Game_32SceneCode.GDMoveJoystickObjects1.length = 0;
gdjs.Game_32SceneCode.GDMoveJoystickObjects2.length = 0;
gdjs.Game_32SceneCode.GDPlatform_9595GroundObjects1.length = 0;
gdjs.Game_32SceneCode.GDPlatform_9595GroundObjects2.length = 0;
gdjs.Game_32SceneCode.GDDoubleJumpPowerupObjects1.length = 0;
gdjs.Game_32SceneCode.GDDoubleJumpPowerupObjects2.length = 0;
gdjs.Game_32SceneCode.GDKeyObjects1.length = 0;
gdjs.Game_32SceneCode.GDKeyObjects2.length = 0;
gdjs.Game_32SceneCode.GDDoorObjects1.length = 0;
gdjs.Game_32SceneCode.GDDoorObjects2.length = 0;
gdjs.Game_32SceneCode.GDSea_9595UrchinObjects1.length = 0;
gdjs.Game_32SceneCode.GDSea_9595UrchinObjects2.length = 0;
gdjs.Game_32SceneCode.GDFinishObjects1.length = 0;
gdjs.Game_32SceneCode.GDFinishObjects2.length = 0;
gdjs.Game_32SceneCode.GDLoseTextObjects1.length = 0;
gdjs.Game_32SceneCode.GDLoseTextObjects2.length = 0;
gdjs.Game_32SceneCode.GDBackground2Objects1.length = 0;
gdjs.Game_32SceneCode.GDBackground2Objects2.length = 0;
gdjs.Game_32SceneCode.GDWinTextObjects1.length = 0;
gdjs.Game_32SceneCode.GDWinTextObjects2.length = 0;
gdjs.Game_32SceneCode.GDWinObjects1.length = 0;
gdjs.Game_32SceneCode.GDWinObjects2.length = 0;
gdjs.Game_32SceneCode.GDLavaObjects1.length = 0;
gdjs.Game_32SceneCode.GDLavaObjects2.length = 0;
gdjs.Game_32SceneCode.GDStartTextObjects1.length = 0;
gdjs.Game_32SceneCode.GDStartTextObjects2.length = 0;
gdjs.Game_32SceneCode.GDStartButtonObjects1.length = 0;
gdjs.Game_32SceneCode.GDStartButtonObjects2.length = 0;
gdjs.Game_32SceneCode.GDCoinCountObjects1.length = 0;
gdjs.Game_32SceneCode.GDCoinCountObjects2.length = 0;
gdjs.Game_32SceneCode.GDArrowsObjects1.length = 0;
gdjs.Game_32SceneCode.GDArrowsObjects2.length = 0;
gdjs.Game_32SceneCode.GDTimerObjects1.length = 0;
gdjs.Game_32SceneCode.GDTimerObjects2.length = 0;
gdjs.Game_32SceneCode.GDADoorObjects1.length = 0;
gdjs.Game_32SceneCode.GDADoorObjects2.length = 0;
gdjs.Game_32SceneCode.GDYourTimeObjects1.length = 0;
gdjs.Game_32SceneCode.GDYourTimeObjects2.length = 0;
gdjs.Game_32SceneCode.GDLore1Objects1.length = 0;
gdjs.Game_32SceneCode.GDLore1Objects2.length = 0;
gdjs.Game_32SceneCode.GDLore2Objects1.length = 0;
gdjs.Game_32SceneCode.GDLore2Objects2.length = 0;
gdjs.Game_32SceneCode.GDLore3Objects1.length = 0;
gdjs.Game_32SceneCode.GDLore3Objects2.length = 0;
gdjs.Game_32SceneCode.GDFinalTextObjects1.length = 0;
gdjs.Game_32SceneCode.GDFinalTextObjects2.length = 0;

gdjs.Game_32SceneCode.eventsList0(runtimeScene);
gdjs.Game_32SceneCode.GDPlayerObjects1.length = 0;
gdjs.Game_32SceneCode.GDPlayerObjects2.length = 0;
gdjs.Game_32SceneCode.GDBackgroundObjects1.length = 0;
gdjs.Game_32SceneCode.GDBackgroundObjects2.length = 0;
gdjs.Game_32SceneCode.GDGoldObjects1.length = 0;
gdjs.Game_32SceneCode.GDGoldObjects2.length = 0;
gdjs.Game_32SceneCode.GDJumpButtonObjects1.length = 0;
gdjs.Game_32SceneCode.GDJumpButtonObjects2.length = 0;
gdjs.Game_32SceneCode.GDMoveJoystickObjects1.length = 0;
gdjs.Game_32SceneCode.GDMoveJoystickObjects2.length = 0;
gdjs.Game_32SceneCode.GDPlatform_9595GroundObjects1.length = 0;
gdjs.Game_32SceneCode.GDPlatform_9595GroundObjects2.length = 0;
gdjs.Game_32SceneCode.GDDoubleJumpPowerupObjects1.length = 0;
gdjs.Game_32SceneCode.GDDoubleJumpPowerupObjects2.length = 0;
gdjs.Game_32SceneCode.GDKeyObjects1.length = 0;
gdjs.Game_32SceneCode.GDKeyObjects2.length = 0;
gdjs.Game_32SceneCode.GDDoorObjects1.length = 0;
gdjs.Game_32SceneCode.GDDoorObjects2.length = 0;
gdjs.Game_32SceneCode.GDSea_9595UrchinObjects1.length = 0;
gdjs.Game_32SceneCode.GDSea_9595UrchinObjects2.length = 0;
gdjs.Game_32SceneCode.GDFinishObjects1.length = 0;
gdjs.Game_32SceneCode.GDFinishObjects2.length = 0;
gdjs.Game_32SceneCode.GDLoseTextObjects1.length = 0;
gdjs.Game_32SceneCode.GDLoseTextObjects2.length = 0;
gdjs.Game_32SceneCode.GDBackground2Objects1.length = 0;
gdjs.Game_32SceneCode.GDBackground2Objects2.length = 0;
gdjs.Game_32SceneCode.GDWinTextObjects1.length = 0;
gdjs.Game_32SceneCode.GDWinTextObjects2.length = 0;
gdjs.Game_32SceneCode.GDWinObjects1.length = 0;
gdjs.Game_32SceneCode.GDWinObjects2.length = 0;
gdjs.Game_32SceneCode.GDLavaObjects1.length = 0;
gdjs.Game_32SceneCode.GDLavaObjects2.length = 0;
gdjs.Game_32SceneCode.GDStartTextObjects1.length = 0;
gdjs.Game_32SceneCode.GDStartTextObjects2.length = 0;
gdjs.Game_32SceneCode.GDStartButtonObjects1.length = 0;
gdjs.Game_32SceneCode.GDStartButtonObjects2.length = 0;
gdjs.Game_32SceneCode.GDCoinCountObjects1.length = 0;
gdjs.Game_32SceneCode.GDCoinCountObjects2.length = 0;
gdjs.Game_32SceneCode.GDArrowsObjects1.length = 0;
gdjs.Game_32SceneCode.GDArrowsObjects2.length = 0;
gdjs.Game_32SceneCode.GDTimerObjects1.length = 0;
gdjs.Game_32SceneCode.GDTimerObjects2.length = 0;
gdjs.Game_32SceneCode.GDADoorObjects1.length = 0;
gdjs.Game_32SceneCode.GDADoorObjects2.length = 0;
gdjs.Game_32SceneCode.GDYourTimeObjects1.length = 0;
gdjs.Game_32SceneCode.GDYourTimeObjects2.length = 0;
gdjs.Game_32SceneCode.GDLore1Objects1.length = 0;
gdjs.Game_32SceneCode.GDLore1Objects2.length = 0;
gdjs.Game_32SceneCode.GDLore2Objects1.length = 0;
gdjs.Game_32SceneCode.GDLore2Objects2.length = 0;
gdjs.Game_32SceneCode.GDLore3Objects1.length = 0;
gdjs.Game_32SceneCode.GDLore3Objects2.length = 0;
gdjs.Game_32SceneCode.GDFinalTextObjects1.length = 0;
gdjs.Game_32SceneCode.GDFinalTextObjects2.length = 0;


return;

}

gdjs['Game_32SceneCode'] = gdjs.Game_32SceneCode;
